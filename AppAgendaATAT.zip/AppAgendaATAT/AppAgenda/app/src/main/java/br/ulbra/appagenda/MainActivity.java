package br.ulbra.appagenda;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private EditText edtNome_main;
    private EditText edtCpf_main;
    private EditText edtTelefone_main;
    private Button btnSalvar_main;
    private PessoaDAO dao;
    private Pessoa pessoa = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edtNome_main = findViewById(R.id.edtNome_main);
        edtCpf_main = findViewById(R.id.edtCpf_main);
        edtTelefone_main = findViewById(R.id.edtTelefone_main);
        btnSalvar_main = findViewById(R.id.btnSalvar_main);
        dao = new PessoaDAO(this);
        //linha de baixo utilizada para atualizar update
        Intent it = getIntent();
        if (it.hasExtra("pessoa")) {
            pessoa = (Pessoa) it.getSerializableExtra("pessoa");
            edtNome_main.setText(pessoa.getNome());
            edtCpf_main.setText(pessoa.getCpf());
            edtTelefone_main.setText(pessoa.getTelefone());

        }
    }

    public void salvar(View view) {
        if (pessoa == null) {
            Pessoa pessoa = new Pessoa();
            pessoa.setNome(edtNome_main.getText().toString());
            pessoa.setCpf(edtCpf_main.getText().toString());
            pessoa.setTelefone(edtTelefone_main.getText().toString());
            long id = dao.inserir(pessoa);
            Toast.makeText(this, "Pessoa inserida no ID de nº:" + id, Toast.LENGTH_LONG).show();
        } else {
            pessoa.setNome(edtNome_main.getText().toString());
            pessoa.setCpf(edtCpf_main.getText().toString());
            pessoa.setTelefone(edtTelefone_main.getText().toString());
            dao.atualizar(pessoa);
            Toast.makeText(this, pessoa.getNome() + ", atualizado com sucesso !!!", Toast.LENGTH_LONG).show();
        }

    }


}



